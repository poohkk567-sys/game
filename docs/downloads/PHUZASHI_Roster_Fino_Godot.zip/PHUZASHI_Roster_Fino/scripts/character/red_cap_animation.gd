extends "res://scripts/character/draft_sprite_animation.gd"
## Whole-body Red Cap drawings. No PHUZASHI artwork or powers in this bank.
const RED_FRAMES: SpriteFrames = preload("res://assets/characters/red_cap/red_cap_frames.res")
const TRANSFORM_FRAMES: SpriteFrames = preload("res://assets/characters/red_awakened/transform_frames.res")
const ALIASES: Dictionary = {"AIR_PUNCH":"PUNCH", "AIR_KICK":"KICK", "BOUND":"HIT"}

func _ready() -> void:
	sprite_frames = RED_FRAMES.duplicate(true)
	sprite_frames.add_animation("TRANSFORM")
	sprite_frames.set_animation_loop("TRANSFORM",false)
	for i in range(16):
		sprite_frames.add_frame("TRANSFORM",TRANSFORM_FRAMES.get_frame_texture("TRANSFORM",i))
	for clip: String in ALIASES:
		sprite_frames.add_animation(clip)
		sprite_frames.set_animation_loop(clip,false)
		for i in range(8):
			sprite_frames.add_frame(clip,RED_FRAMES.get_frame_texture(ALIASES[clip],i))
	centered = false
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var cutout := ShaderMaterial.new()
	cutout.shader = CUTOUT
	material = cutout
	visible = false

func show_state(state: String, enabled: bool, progress: float = -1.0) -> bool:
	# Crouch and guard enter then hold their final pose instead of cycling back.
	if progress < 0.0 and state in ["CROUCH","GUARD"]:
		var rig: Node2D = get_parent()
		progress = minf(rig.clock / 0.35,0.999)
	var supported: bool = super.show_state(state,enabled,progress)
	if state == "TRANSFORM":
		var transform_factor: float = float(TRANSFORM_FRAMES.get_meta("scale"))
		var transform_pivot: Vector2 = TRANSFORM_FRAMES.get_meta("pivot")
		scale = Vector2.ONE*FRAME_SCALE*transform_factor
		position = -transform_pivot*FRAME_SCALE*transform_factor
		return supported
	var source: String = ALIASES.get(state,state)
	var factor: float = float(RED_FRAMES.get_meta("scales").get(source,1.0))
	var pivot: Vector2 = RED_FRAMES.get_meta("pivot")
	scale = Vector2.ONE * FRAME_SCALE * factor
	position = -pivot * FRAME_SCALE * factor
	return supported

func frame_at_progress(state: String, progress: float) -> int:
	if state == "TRANSFORM":
		return mini(15,floori(clampf(progress,0.0,0.99999)*16.0))
	var boundaries: Array = []
	if state == "KICK":
		boundaries = [0.0,0.10,0.20,0.28,0.40,0.65,0.82,0.94]
	elif state == "KICK_2":
		boundaries = [0.0,0.10,0.20,0.30,0.64,0.73,0.83,0.94]
	if boundaries.is_empty():
		return super.frame_at_progress(state,progress)
	var result: int = 0
	for i in range(boundaries.size()):
		if progress >= float(boundaries[i]):
			result = i
	return result
